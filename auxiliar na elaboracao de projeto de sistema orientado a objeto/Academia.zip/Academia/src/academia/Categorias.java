
package academia;

public interface Categorias {
    public void corrida();
    public void musculacao();
}
