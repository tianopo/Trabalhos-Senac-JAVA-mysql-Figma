
package academia;

public class Velocidade implements Categorias{
    
    @Override
    public void corrida(){
        System.out.println("10 tiros de 200 metros \n 5km ciclismo em tempo\n");
    }
    
    @Override
    public void musculacao(){
        System.out.println("3 repetições de 10 na leg press e agachamento em pé");
    }
}
